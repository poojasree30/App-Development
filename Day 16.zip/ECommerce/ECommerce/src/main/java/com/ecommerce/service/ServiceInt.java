package com.ecommerce.service;

import com.ecommerce.entity.model;

import java.util.List;



public interface ServiceInt {
    public List<model>getdatas();

}