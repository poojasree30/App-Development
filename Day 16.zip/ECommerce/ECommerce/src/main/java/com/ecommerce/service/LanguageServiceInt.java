package com.ecommerce.service;

import com.ecommerce.entity.Language;

import java.util.List;

public interface LanguageServiceInt {
    public List<Language> getdatas();
}
