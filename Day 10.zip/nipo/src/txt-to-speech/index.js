import Main from "./modules/main"

export default function speak() {
    const VoiceAssistent = new Main();
    return VoiceAssistent

}